package com.cts.employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PssRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
