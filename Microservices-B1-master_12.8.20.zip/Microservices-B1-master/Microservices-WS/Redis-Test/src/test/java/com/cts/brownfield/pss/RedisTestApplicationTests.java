package com.cts.brownfield.pss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedisTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
