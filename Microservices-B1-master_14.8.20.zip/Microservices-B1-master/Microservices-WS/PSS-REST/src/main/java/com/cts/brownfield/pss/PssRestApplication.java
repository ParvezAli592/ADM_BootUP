package com.cts.brownfield.pss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PssRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(PssRestApplication.class, args);
	}

}
