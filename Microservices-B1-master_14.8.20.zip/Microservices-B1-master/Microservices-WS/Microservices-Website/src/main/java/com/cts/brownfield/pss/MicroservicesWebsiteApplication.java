package com.cts.brownfield.pss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicesWebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicesWebsiteApplication.class, args);
	}

}
