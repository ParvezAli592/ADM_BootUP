package com.cts.product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartSeeviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
