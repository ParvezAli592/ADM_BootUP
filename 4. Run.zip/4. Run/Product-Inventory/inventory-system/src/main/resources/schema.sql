drop table products if exists



 create table products (id bigint not null, description varchar(255), price double, primary key (id))
