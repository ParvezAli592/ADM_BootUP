/*
 *@author Sumanjula Roy
 *@version 1.0
 *
 */

package com.assignment.exceptionhandling;

// TODO: Auto-generated Javadoc
/**
 *  Class ParameterNotFoundException.
 */
public class ParameterNotFoundException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -9079454849611061075L;

	/**
	 * Instantiates a new parameter not found exception.
	 */
	public ParameterNotFoundException() {
		super();
	}

	/**
	 * Instantiates a new parameter not found exception.
	 *
	 * @param message the message
	 */
	public ParameterNotFoundException(final String message) {
		super(message);
	}

}
