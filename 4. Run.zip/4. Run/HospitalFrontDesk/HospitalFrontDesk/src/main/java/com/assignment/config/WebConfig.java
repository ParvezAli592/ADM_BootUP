/*
 *@author Sumanjula Roy
 *@version 1.0
 *
 */
package com.assignment.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

/**
 * Class to toggle between XML and JSON urls for Requirement 1
 */
@Configuration
@EnableWebMvc
public class WebConfig{

/**
 * Configure content negotiation to give xml and json as responses.
 *
 * @param configurer
 */
public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {

    //set path extension to true
    configurer.defaultContentType(MediaType.APPLICATION_JSON).
    mediaType("json", MediaType.APPLICATION_JSON).
    mediaType("xml", MediaType.APPLICATION_XML);
    
  }
}