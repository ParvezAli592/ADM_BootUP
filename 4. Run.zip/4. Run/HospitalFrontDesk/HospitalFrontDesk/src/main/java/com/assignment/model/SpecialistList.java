/*
 *@author Sumanjula Roy
 *@version 1.0
 *
 */
package com.assignment.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * Configuration Class to fetch values from data stored in properties file
 * Values to be populated from properties file
 */
@Configuration
@PropertySource("classpath:specialist.properties")
@ConfigurationProperties(prefix = "specialist")
@XmlRootElement
public class SpecialistList {
	
	/** The specialist list. */
	private List<Specialist> specialistList = new ArrayList<>();

	/**
	 * Instantiates a new specialist list.
	 */
	public SpecialistList() {
	}

	/**
	 * Gets the specialist list.
	 *
	 * @return the specialist list
	 */
	public List<Specialist> getSpecialistList() {
		return specialistList;
	}

	/**
	 * Find by hospital id and type.
	 *
	 * @param hospitalId 
	 * @param type 
	 * @return list of specialists found from hospital id and specialist type
	 */
	public List<Specialist> findByHospitalIdAndType(int hospitalId, String type) {
		List<Specialist> valList = new ArrayList<>();
		for (Specialist s : specialistList) {
			if (s.getHospitalId() == hospitalId && type.equalsIgnoreCase(s.getType())
					&& "Y".equalsIgnoreCase(s.getIsAvailable())) {
				valList.add(s);
			}
		}
		return valList;
	}

	/**
	 * Find by name and day.
	 *
	 * @param name 
	 * @param appointmentDay 
	 * @return the specialist present according to name and appointment day
	 */
	public Specialist findByNameAndDay(String name, String appointmentDay) {
		for (Specialist s : specialistList) {
			if (name.equalsIgnoreCase(s.getName()) && "Y".equalsIgnoreCase(s.getIsAvailable())) {
				for (String day : s.getAvailableday()) {
					if (appointmentDay.equalsIgnoreCase(day)) {
						return s;
					}
				}
			}
		}
		return null;
	}

	/**
	 * POJO Class Specialist.
	 */
	public static class Specialist {
		
		/** The type. */
		private String type;
		
		/** The name. */
		private String name;
		
		/** The availableday. */
		private List<String> availableday;
		
		/** The available time. */
		private String availableTime;
		
		/** The is available. */
		private String isAvailable;
		
		/** The hospital id. */
		private int hospitalId;

		/**
		 * Gets the type.
		 *
		 * @return the type
		 */
		public String getType() {
			return type;
		}

		/**
		 * Sets the type.
		 *
		 * @param type 
		 */
		public void setType(String type) {
			this.type = type;
		}

		/**
		 * Gets the name.
		 *
		 * @return the name
		 */
		public String getName() {
			return name;
		}

		/**
		 * Sets the name.
		 *
		 * @param name
		 */
		public void setName(String name) {
			this.name = name;
		}

		/**
		 * Gets the availableday.
		 *
		 * @return the availableday
		 */
		public List<String> getAvailableday() {
			return availableday;
		}

		/**
		 * Sets the availableday.
		 *
		 * @param availableday 
		 */
		public void setAvailableday(List<String> availableday) {
			this.availableday = availableday;
		}

		/**
		 * Gets the available time.
		 *
		 * @return the available time
		 */
		public String getAvailableTime() {
			return availableTime;
		}

		/**
		 * Sets the available time.
		 *
		 * @param availableTime 
		 */
		public void setAvailableTime(String availableTime) {
			this.availableTime = availableTime;
		}

		/**
		 * Gets the checks if is available.
		 *
		 * @return the checks if is available
		 */
		public String getIsAvailable() {
			return isAvailable;
		}

		/**
		 * Sets the checks if is available.
		 *
		 * @param isAvailable 
		 */
		public void setIsAvailable(String isAvailable) {
			this.isAvailable = isAvailable;
		}

		/**
		 * Gets the hospital id.
		 *
		 * @return the hospital id
		 */
		public int getHospitalId() {
			return hospitalId;
		}

		/**
		 * Sets the hospital id.
		 *
		 * @param hospitalId
		 */
		public void setHospitalId(int hospitalId) {
			this.hospitalId = hospitalId;
		}
	}
}
