/*
 *@author Sumanjula Roy
 *@version 1.0
 *
 */
package com.assignment.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.controller.HospitalController;
import com.assignment.exceptionhandling.HospitalNotFoundException;
import com.assignment.exceptionhandling.SpecialistNotFoundException;
import com.assignment.model.Booking;
import com.assignment.model.HospitalList;
import com.assignment.model.HospitalList.Hospital;
import com.assignment.model.PatientList;
import com.assignment.model.PatientList.Patient;
import com.assignment.model.SpecialistList;
import com.assignment.model.SpecialistList.Specialist;

/**
 * Class HospitalService.
 */
@Service
public class HospitalService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(HospitalService.class);
	
	/** The hospital list. */
	@Autowired
	private HospitalList hospitalList;
	
	/** The specialist list. */
	@Autowired
	private SpecialistList specialistList;
	
	/** The patient list. */
	@Autowired
	private PatientList patientList;

	/**
	 * Gets the specialists.
	 *
	 * @return the specialists
	 * @throws HospitalServiceException 
	 */
	public List<Specialist> getSpecialists() throws HospitalServiceException {
		return specialistList.getSpecialistList();
	}

	/**
	 * Gets the specialists.
	 *
	 * @param hospitalName the hospital name
	 * @param specialistType the specialist type
	 * @return the specialists
	 * @throws HospitalNotFoundException the hospital not found exception
	 * @throws SpecialistNotFoundException the specialist not found exception
	 */
	public List<Specialist> getSpecialists(String hospitalName, String specialistType)
			throws HospitalNotFoundException, SpecialistNotFoundException {

		// Search for hospital by input value for hospitalName
		Hospital h = hospitalList.findByName(hospitalName);
		if (h == null) {
			throw new HospitalNotFoundException(
					"No hospital found by the given name. Kindly provide another hospital name.");
		}
		// Search for specialist according to hospital id and specialist type
		List<Specialist> spcList = specialistList.findByHospitalIdAndType(h.getId(), specialistType);
		if (spcList == null || spcList.size() == 0) {
			throw new SpecialistNotFoundException("No Specialists match given criteria.");
		}
		return spcList;
	}

	/**
	 * Gets the booking.
	 *
	 * @param specialistName the specialist name
	 * @param appointmentDay the appointment day
	 * @param patientName the patient name
	 * @return the booking
	 * @throws SpecialistNotFoundException the specialist not found exception
	 */
	public Booking getBooking(String specialistName, String appointmentDay, String patientName)
			throws SpecialistNotFoundException {
		Specialist s = specialistList.findByNameAndDay(specialistName, appointmentDay);
		if (s == null) {
			throw new SpecialistNotFoundException("No Specialist details found.");
		}
		return new Booking(specialistName, patientName, appointmentDay, s.getAvailableTime());
	}

	/**
	 * Gets the number of beds.
	 *
	 * @param hospitalName the hospital name
	 * @return the number of beds
	 * @throws HospitalNotFoundException the hospital not found exception
	 */
	public int getNumberOfBeds(String hospitalName) throws HospitalNotFoundException {
		Hospital h = hospitalList.findByName(hospitalName);
		if (h == null) {
			throw new HospitalNotFoundException("No hospital found by the given name. Kindly provide another hospital name.");
		}
		List<Patient> valList = patientList.findByHospitalIdAndStatus(h.getId(), "DISCHARGE");
		return valList.size();
	}

}
