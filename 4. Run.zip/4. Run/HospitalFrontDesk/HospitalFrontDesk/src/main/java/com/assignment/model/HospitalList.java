/*
 *@author Sumanjula Roy
 *@version 1.0
 *
 */
package com.assignment.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * Configuration Class HospitalList to return hospital details from property file.
 */
@Configuration
@PropertySource("classpath:hospitalAndPatientDetails.properties")
@ConfigurationProperties(prefix = "hospital")
public class HospitalList {
	
	/** The hospital list. */
	private List<Hospital> hospitalList = new ArrayList<>();

	/**
	 * Instantiates a new hospital list.
	 */
	public HospitalList() {
	}

	/**
	 * Gets the hospital list.
	 *
	 * @return the hospital list
	 */
	public List<Hospital> getHospitalList() {
		return hospitalList;
	}

	/**
	 * Find by name.
	 *
	 * @param name 
	 * @return Hospital which matches the input name
	 */
	public Hospital findByName(String name) {
		for (Hospital h : hospitalList) {
			if (name.equalsIgnoreCase(h.getName())) {
				return h;
			}
		}
		return null;
	}

	/**
	 * POJO Class Hospital.
	 */
	public static class Hospital {
		
		/** The name. */
		private String name;
		
		/** The id. */
		private int id;

		/**
		 * Instantiates a new hospital.
		 */
		public Hospital() {
		}

		/**
		 * Gets the name.
		 *
		 * @return the name
		 */
		public String getName() {
			return name;
		}

		/**
		 * Sets the name.
		 *
		 * @param name 
		 */
		public void setName(String name) {
			this.name = name;
		}

		/**
		 * Gets the id.
		 *
		 * @return the id
		 */
		public int getId() {
			return id;
		}

		/**
		 * Sets the id.
		 *
		 * @param id 
		 */
		public void setId(int id) {
			this.id = id;
		}
	}
}
