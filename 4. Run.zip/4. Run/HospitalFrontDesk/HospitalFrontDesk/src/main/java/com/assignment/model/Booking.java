/*
 *@author Sumanjula Roy
 *@version 1.0
 *
 */
package com.assignment.model;

/**
 * POJO Class Booking.
 */
public class Booking 
{
	
	/** The specialist name. */
	private String specialistName;
	
	/** The patient name. */
	private String patientName;
	
	/** The appointment day. */
	private String appointmentDay;
	
	/** The appointment time. */
	private String appointmentTime;
	
	/**
	 * Instantiates a new booking.
	 *
	 * @param specialistName the specialist name
	 * @param patientName the patient name
	 * @param appointmentDay the appointment day
	 * @param appointmentTime the appointment time
	 */
	public Booking(String specialistName, String patientName, String appointmentDay, String appointmentTime) 
	{
		this.specialistName = specialistName;
		this.patientName = patientName;
		this.appointmentDay = appointmentDay;
		this.appointmentTime = appointmentTime;
	}
	
	/**
	 * Gets the specialist name.
	 *
	 * @return the specialist name
	 */
	public String getSpecialistName() {
		return specialistName;
	}
	
	/**
	 * Sets the specialist name.
	 *
	 * @param specialistName 
	 */
	public void setSpecialistName(String specialistName) {
		this.specialistName = specialistName;
	}
	
	/**
	 * Gets the patient name.
	 *
	 * @return the patient name
	 */
	public String getPatientName() {
		return patientName;
	}
	
	/**
	 * Sets the patient name.
	 *
	 * @param patientName
	 */
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	
	/**
	 * Gets the appointment day.
	 *
	 * @return the appointment day
	 */
	public String getAppointmentDay() {
		return appointmentDay;
	}
	
	/**
	 * Sets the appointment day.
	 *
	 * @param appointmentDay 
	 */
	public void setAppointmentDay(String appointmentDay) {
		this.appointmentDay = appointmentDay;
	}
	
	/**
	 * Gets the appointment time.
	 *
	 * @return the appointment time
	 */
	public String getAppointmentTime() {
		return appointmentTime;
	}
	
	/**
	 * Sets the appointment time.
	 *
	 * @param appointmentTime 
	 */
	public void setAppointmentTime(String appointmentTime) {
		this.appointmentTime = appointmentTime;
	}
}
