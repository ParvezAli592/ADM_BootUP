/*
 *@author Sumanjula Roy
 *@version 1.0
 *
 */
package com.assignment.exceptionhandling;

/**
 * Exception Class BookingException to throw Business Exception during appointment booking
 */
public class BookingException extends Exception {

	private static final long serialVersionUID = -9079454849611061074L;

	/**
	 * Instantiates a new booking exception.
	 */
	public BookingException() {
		super();
	}

	/**
	 * Instantiates a new booking exception.
	 *
	 * @param message to be displayed to user when this exception is encountered.
	 */
	public BookingException(final String message) {
		super(message);
	}

}
