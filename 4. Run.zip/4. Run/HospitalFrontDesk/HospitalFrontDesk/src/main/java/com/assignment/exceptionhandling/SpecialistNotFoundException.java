/*
 *@author Sumanjula Roy
 *@version 1.0
 *
 */
package com.assignment.exceptionhandling;

/**
 *  Class SpecialistNotFoundException.
 */
public class SpecialistNotFoundException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -9079454849611061074L;

	/**
	 * Instantiates a new specialist not found exception.
	 */
	public SpecialistNotFoundException() {
		super();
	}

	/**
	 * Instantiates a new specialist not found exception.
	 *
	 * @param message the message
	 */
	public SpecialistNotFoundException(final String message) {
		super(message);
	}

}
