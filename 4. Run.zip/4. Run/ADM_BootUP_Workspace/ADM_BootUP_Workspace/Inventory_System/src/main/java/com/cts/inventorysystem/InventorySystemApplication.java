/*
 *@author Sheikh Parvez Ali Mondal
 *@version 1.0
 *
 */
package com.cts.inventorysystem;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * Main Application Class. 
 * @EnableFeignClients annotation present to enable FeignClients for Requirement 2
 *                     
 */

@EnableFeignClients
@SpringBootApplication
public class InventorySystemApplication {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(InventorySystemApplication.class);

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		SpringApplication.run(InventorySystemApplication.class, args);
		LOGGER.info("Welcome to Inventory System Application");
	}

}
