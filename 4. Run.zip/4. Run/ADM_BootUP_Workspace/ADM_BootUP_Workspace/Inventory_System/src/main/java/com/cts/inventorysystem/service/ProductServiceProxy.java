/*
 *@author Sheikh Parvez Ali Mondal
 *@version 1.0
 *
 */
package com.cts.inventorysystem.service;

import java.util.List;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.cts.inventorysystem.model.Product;

@FeignClient(name="product-service", url = "http://localhost:8081")
@RibbonClient(name="product-proxy")
public interface ProductServiceProxy {
	
	/**
	 * Get products in the product catalog application
	 * 
	 * @param id the product id
	 * @return Product present in the inventory
	 */
	@GetMapping(value = "/api/products/getProduct/{id}")
	public Product findProductById(@PathVariable("id") long id);
	
	/**
	 * Get list of all products in the product catalog application
	 * 
	 * @return List of all the Product available in the inventory
	 */
	@GetMapping(value = "/api/products/getAllProducts")
	public List<Product> findAll();

	/**
	 * Save products in the product catalog application
	 * 
	 * @param the product object
	 * @return Saved Product from the inventory
	 */
	@PostMapping(value = "/api/products/saveProduct")
	public void save(Product product);

	/**
	 * Delete products in the product catalog application
	 * 
	 * @return Deleted Product from the inventory
	 */
	@DeleteMapping("/api/products/deleteProduct/{id}")
	public void deleteById(@PathVariable("id") long id);

	/**
	 * Ping product catalog application
	 * 
	 * @return boolean value
	 */
	@GetMapping("/api/products/ping")
	public Boolean ping();
}
