/*
 *@author Sheikh Parvez Ali Mondal 
 *@version 1.0
 *
 */
package com.cts.bootup.run.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

/**
 * POJO Class Product.
 */
@Entity
@Table(name = "PRODUCT")
@DynamicUpdate
public class Product {

	/** The product id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	/** The product name. */
	private String name;

	/** The product price. */
	private double price;

	/** The product description. */
	private String description;

	public Product() {
		super();
	}

	public Product(String name) {
		super();
		this.name = name;
	}

	/**
	 * Instantiates a new product.
	 *
	 * @param name        the product name
	 * @param price       the product price
	 * @param description the product description
	 */
	public Product(String name, double price, String description) {
		super();
		this.name = name;
		this.price = price;
		this.description = description;
	}

	/**
	 * Instantiates a new product.
	 *
	 * @param id          the product id
	 * @param name        the product name
	 * @param price       the product price
	 * @param description the product description
	 */
	public Product(long id, String name, double price, String description) {
		this();
		this.id = id;
		this.name = name;
		this.price = price;
		this.description = description;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * Sets the id
	 *
	 * @param id
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name
	 *
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the price.
	 *
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * Sets the price
	 *
	 * @param price
	 */
	public void setPrice(double price) {
		this.price = price;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the description
	 *
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

}
