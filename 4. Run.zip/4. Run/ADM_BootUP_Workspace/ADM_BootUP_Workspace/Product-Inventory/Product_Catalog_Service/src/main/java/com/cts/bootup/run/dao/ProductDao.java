/*
 *@author Sheikh Parvez Ali Mondal
 *@version 1.0
 *
 */
package com.cts.bootup.run.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cts.bootup.run.entity.Product;


/**
 * Product Interface.
 */
public interface ProductDao extends JpaRepository<Product, Long>{

	/**
	 * Query to get Product Details when user provides name of the product
	 */
	@Query(value = "FROM Product u where lower(u.name) like %:name%")
	List<Product> findByName(String name);
}
