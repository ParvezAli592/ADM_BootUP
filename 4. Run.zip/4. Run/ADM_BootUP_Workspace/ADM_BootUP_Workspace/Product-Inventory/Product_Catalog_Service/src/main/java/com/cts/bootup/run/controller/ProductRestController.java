/*
 *@author Sheikh Parvez Ali Mondal
 *@version 1.0
 *
 */
package com.cts.bootup.run.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.bootup.run.entity.Product;
import com.cts.bootup.run.exception.BannedProductException;
import com.cts.bootup.run.exception.ParameterNotFoundException;
import com.cts.bootup.run.service.ProductService;

/**
 * Controller Class ProductRestController.
 */
@RestController
@CrossOrigin
@RequestMapping("/api/products")
public class ProductRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProductRestController.class);

	@Autowired
	private ProductService productService;

	/** Check whether application is Up or not */
	@GetMapping("/ping")
	public Boolean ping() {
		return true;
	}

	/**
	 * Get list of all products in the inventory
	 * 
	 * @return List of Product available in the inventory
	 */
	@GetMapping("/getAllProducts")
	public List<Product> getAllProducts() {
		return productService.getAllProducts();
	}

	/**
	 * Gets the product information available in the inventory
	 * 
	 * @param id the product id
	 * @return Details of the Product
	 */
	@GetMapping("/getProduct/{id}")
	public Product getProductById(@PathVariable("id") long id) {
		Optional<Product> fetchedProduct = productService.getProductByProductId(id);
		return fetchedProduct.orElse(null);
	}

	/**
	 * Get the product information available in the inventory for Retail Partner
	 * 
	 * @param id the product id
	 * @return Details of the Product required for Promotion by Retail Partner
	 */
	@GetMapping("/getProductForRetailPartner/{id}")
	public ResponseEntity<Product> getProductByIdForRetailPartner(@PathVariable("id") long id) {
		return productService.getProductByIdForRetailPartner(id);
	}

	/**
	 * Method will Persist a New Product. If the product is in banned product list
	 * then method will throw a error.
	 * 
	 * @param product the product object
	 * @return Http Response of the persisted product
	 * @throws BannedProductException     the banned product exception
	 * @throws ParameterNotFoundException the parameter not found exception
	 */
	@PostMapping("/saveProduct")
	public ResponseEntity<Product> saveProduct(@RequestBody Product product) throws ParameterNotFoundException {
		if (product == null) {
			throw new ParameterNotFoundException("Product Details not provided.");
		}
		try {
			Product savedProd = productService.save(product);
			return ResponseEntity.ok(savedProd);
		} catch (BannedProductException e) {
			LOGGER.error("Banned Product can't be added to inventory", e);
			System.out.println("Banned Product can't be added to Inventory");
			return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED).build();
		}
	}

	/**
	 * Method will persist list of New products in the inventory
	 * 
	 * @param products the product object
	 * @return List of saved Products
	 */
	@PostMapping("/saveAllProducts")
	public List<Product> saveProduct(@RequestBody List<Product> products) {
		return productService.saveAll(products);
	}

	/**
	 * Method will delete the product from the inventory
	 * 
	 * @param id the product id
	 * @return the deleted product id
	 */
	@DeleteMapping("/deleteProduct/{id}")
	public void deleteProductById(@PathVariable("id") long id) {
		productService.deleteProductByProductId(id);
	}

	/**
	 * Method will get the Price of the product. Request which gets the price of the
	 * product based on input parameters product id. This mapping request is Cache
	 * Configured.
	 * 
	 * @param id the product id
	 * @return the price of the product
	 */
	@GetMapping("/getPrice/{id}")
	public Double getPriceByProductId(@PathVariable("id") long id) {
		return productService.getPriceByProductId(id);
	}

	/**
	 * Updates the Price. Request which updates the price of the product based on
	 * input parameters product id.
	 * 
	 * @param id      the product id
	 * @param product the product object
	 * @return updated price response
	 */
	@PutMapping("/updateProduct/{id}")
	public ResponseEntity<Product> updateProduct(@RequestBody Product product) throws ParameterNotFoundException {
		try {
			Product savedProd = productService.save(product);
			if (product == null) {
				throw new ParameterNotFoundException("Product Details not provided.");
			}
			return ResponseEntity.ok(savedProd);
		} catch (BannedProductException e) {
			LOGGER.error("Banned Products can't be updated to the inventory", e);
			return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED).build();
		}
	}

	/**
	 * Updates the Price.
	 * 
	 * @param id    the product id
	 * @param price the price of the product
	 * @return updated price response
	 */
	@PutMapping("/updatePriceOfTheProduct/{id}/{price}")
	public Product updatePrice(@PathVariable("id") long id, @PathVariable("price") double price) {
		return productService.updatePrice(id, price);
	}

}
