/*
 *@author Sheikh Parvez Ali Mondal
 *@version 1.0
 *
 */
package com.cts.bootup.run.exception;

public class BannedProductException extends Exception {
	
	/**
	 *  Class BannedProductException.
	 */
	private static final long serialVersionUID = -4509561012775565001L;

	/**
	 * Instantiates banned product exception.
	 */
	public BannedProductException() {
		super();
	}
	
	/**
	 * Instantiates banned product exception.
	 *
	 * @param message to be displayed to user when this exception is encountered.
	 */
	public BannedProductException(String message) {
		super(message);
	}
	
	public BannedProductException(Throwable throwable) {
		super(throwable);
	}
	
	public BannedProductException(String message, Throwable throwable) {
		super(message, throwable);
	}
}
