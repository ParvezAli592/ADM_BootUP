/*
 *@author Sheikh Parvez Ali Mondal
 *@version 1.0
 *
 */
package com.cts.bootup.run.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cts.bootup.run.ProductCatalogApplication;
import com.cts.bootup.run.dao.ProductDao;
import com.cts.bootup.run.entity.Product;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
@ConditionalOnClass({ String.class })
public class DefaultDataOnStartupConfiguration {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ProductCatalogApplication.class);

	@Autowired
	private ProductDao productDao;

	@Bean
	public String loadDataOnStartup() {
		
		LOGGER.info("Configure Defaults on Startup of the Application");

		Product product = new Product("P1", 10.0, "P1 desc");
		productDao.save(product);

		return new String("Populated");
	}
}
