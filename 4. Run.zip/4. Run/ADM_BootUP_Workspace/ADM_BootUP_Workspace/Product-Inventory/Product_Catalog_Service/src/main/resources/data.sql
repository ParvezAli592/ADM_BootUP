insert into product(id, name, price, description) values(1, 'Thinkpad', 10000, 'Laptop');
insert into product(id, name, price, description) values(2, 'IPad', 12000, 'Tablet');