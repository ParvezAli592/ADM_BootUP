/*
 *@author Sheikh Parvez Ali Mondal
 *@version 1.0
 *
 */
package com.cts.bootup.run.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.cts.bootup.run.config.BannedProduct;
import com.cts.bootup.run.dao.ProductDao;
import com.cts.bootup.run.entity.Product;
import com.cts.bootup.run.exception.BannedProductException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class ProductService.
 */
@Service
public class ProductServiceImpl implements ProductService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProductService.class);

	@Autowired
	private ProductDao productDao;

	@Autowired
	private BannedProduct bannedProduct;

	/**
	 * Gets the list of Products.
	 *
	 * @return the list of Products
	 * @throws ProductServiceException
	 */
	@Override
	public List<Product> getAllProducts() {
		return productDao.findAll();
	}

	/**
	 * Gets the Product.
	 *
	 * @param id the product id
	 * @return the Product
	 */
	@Override
	public Optional<Product> getProductByProductId(long id) {
		try {
			Thread.sleep(100 * 5);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return productDao.findById(id);
	}

	/**
	 * Gets the Product.
	 *
	 * @param name the product name
	 * @return the Product
	 */
	@Override
	public List<Product> getProductByProductName(String name) {
		return productDao.findByName(name);
	}

	/**
	 * Save the Product.
	 *
	 * @param product the product object
	 * @return product response
	 */
	@Override
	public Product save(Product product) throws BannedProductException {
		String bannedProd = bannedProduct.getBanned();
		if (product.getName().equalsIgnoreCase(bannedProd)) {
			throw new BannedProductException("Product category Grocery not allowed");
		}

		return productDao.save(product);
	}

	/**
	 * Save list of Products.
	 *
	 * @param products the product object
	 * @return list of product response
	 */
	@Override
	public List<Product> saveAll(List<Product> products) {
		return productDao.saveAll(products);
	}

	/**
	 * Delete the Products.
	 *
	 * @param id the product id
	 * @return deleted product response
	 */
	@Override
	public void deleteProductByProductId(long id) {
		productDao.deleteById(id);
	}

	/**
	 * Gets the Price of the Product. method is to demarcate it with @Cacheable and
	 * parameterize it with the name of the cache where the results would be stored
	 *
	 * @param id the product id
	 * @return the price
	 */
	@Cacheable("priceOfProduct")
	@Override
	public Double getPriceByProductId(long id) {
		Optional<Product> product = productDao.findById(id);
		Product prod = product.orElse(null);
		if (prod != null) {
			return prod.getPrice();
		}
		return null;
	}

	/**
	 * Method used to indicate the removal of one or more/all values – so that fresh
	 * values can be loaded into the cache again
	 */
	@CacheEvict(value = "priceOfProduct", allEntries = true)
	@Scheduled(fixedDelay = 180000)
	public void resetAllEntries() {
		System.out.println("Cache Flushed");
		LOGGER.info("Cache is cleaned");
	}

	/**
	 * Gets the Price of the Product.
	 *
	 * @param id the product id
	 * @return the price
	 */
	@Override
	public Product updatePrice(long id, double price) {
		Optional<Product> product = productDao.findById(id);
		Product prod = product.orElse(null);
		if (prod != null) {
			prod.setPrice(price);
			Product savedProd = productDao.save(prod);
			return savedProd;
		}
		return null;
	}

	/**
	 * Gets the Product.
	 *
	 * @param id the product id
	 * @return the price
	 */
	@Override
	public ResponseEntity<Product> getProductByIdForRetailPartner(long id) {

		Optional<Product> productOptional = productDao.findById(id);

		Product fetchedProductDetails = productOptional.get();

		if (fetchedProductDetails != null) {
			if (fetchedProductDetails.getId() == 1) {
				return ResponseEntity.status(HttpStatus.FOUND).body(fetchedProductDetails);
			} else {
				return ResponseEntity.ok().body(fetchedProductDetails);
			}
		}
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}
}
