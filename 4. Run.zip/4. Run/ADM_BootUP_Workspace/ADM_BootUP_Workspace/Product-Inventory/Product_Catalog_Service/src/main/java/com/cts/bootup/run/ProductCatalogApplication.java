/*
 *@author Sheikh Parvez Ali Mondal
 *@version 1.0
 *
 */
package com.cts.bootup.run;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.cts.bootup.run.config.BannedProduct;

/**
 * Main Application Class.
 * 
 * @EnableCaching annotation present to enable caching for Requirement 1
 * @EnableFeignClients annotation present to enable FeignClients for Requirement
 *                     3
 * 
 */
@EnableFeignClients
@EnableScheduling
@EnableCaching
@SpringBootApplication
public class ProductCatalogApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProductCatalogApplication.class);

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(ProductCatalogApplication.class, args);
		BannedProduct bp = ctx.getBean(BannedProduct.class);
		System.out.println("The Product which is Banned for entry is " + bp.getBanned());
		LOGGER.info("Welcome to Product Catalog Application");
	}
}
