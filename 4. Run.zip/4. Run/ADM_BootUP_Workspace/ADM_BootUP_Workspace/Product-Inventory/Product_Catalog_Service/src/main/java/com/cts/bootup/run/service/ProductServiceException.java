/*
 *@author Sheikh Parvez Ali Mondal
 *@version 1.0
 *
 */
package com.cts.bootup.run.service;

/**
 *  Class ProductServiceException.
 */
public class ProductServiceException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -470180507998010368L;

	/**
	 * Instantiates a new product service exception.
	 */
	public ProductServiceException() {
		super();
	}

	/**
	 * Instantiates a new product service exception.
	 *
	 * @param message the message
	 */
	public ProductServiceException(final String message) {
		super(message);
	}
}
