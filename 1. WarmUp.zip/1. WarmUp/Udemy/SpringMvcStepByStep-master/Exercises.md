#Spring MVC Exercises

## Read Documentation
http://docs.spring.io/spring/docs/current/spring-framework-reference/html/mvc.html

## Try a Few Spring Exercies From the Guide
https://spring.io/guides

## Setup Showcase Application
https://github.com/spring-projects/spring-mvc-showcase

## Try using the Spring Initializr
https://start.spring.io
