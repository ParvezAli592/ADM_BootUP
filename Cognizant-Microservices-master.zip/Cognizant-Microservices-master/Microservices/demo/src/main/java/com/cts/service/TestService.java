package com.cts.service;

import org.springframework.stereotype.Service;

@Service
public class TestService {
	
	public void test() {
		System.out.println("--- Hello test method");
	}

}
