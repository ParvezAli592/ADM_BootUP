package com.price;

public interface PriceMatrix {

	double getItemPrice(String itemCode);

}